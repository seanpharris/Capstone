import csv
from hashtable import ChainingHashTable
from house import House

#  stores package data from  WGUPS Package File.csv file used to pass to trucks list
house_list = []
#  calls ChainingHashTable class for functions used on the tables
housing_table = ChainingHashTable()


#  O(N) -- Retrieves data from package CSV file and creates each item as an object in the table
def get_house_data_csv():
    with open("HousingData.csv") as infile:
        csv_reader = csv.reader(infile)
        for row in csv_reader:
            home = House(row)
            housing_table.insert(home.house_id, home)
        return housing_table

