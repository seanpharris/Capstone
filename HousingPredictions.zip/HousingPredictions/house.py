# Class: Package - stores info related to the package
class House(object):
    def __init__(self, house_list):
        self.house_id = int(house_list[0])
        self.MSSubClass = house_list[1]
        self.MSZoning = house_list[2]
        self.LotFrontage = house_list[3]
        self.LotArea = house_list[4]
        self.Street = house_list[5]
        self.Alley = house_list[6]
        self.LotShape = house_list[7]
        self.LandContour = house_list[8]
        self.Utilities = house_list[9]
        self.LotConfig = house_list[10]
        self.LandSlope = house_list[11]
        self.Neighborhood = house_list[12]
        self.Condition1 = house_list[13]
        self.Condition2 = house_list[14]
        self.BldgType = house_list[15]
        self.HouseStyle = house_list[16]
        self.StreetOverallQual = house_list[17]
        self.OverallCond = house_list[18]
        self.YearBuilt = house_list[19]
        self.YearRemodAdd = house_list[20]
        self.RoofStyle = house_list[21]
        self.RoofMatl = house_list[22]
        self.Exterior1st = house_list[23]
        self.Exterior2nd = house_list[24]
        self.MasVnrType = house_list[25]
        self.MasVnrArea = house_list[26]
        self.ExterQual = house_list[27]
        self.ExterCond = house_list[28]
        self.Foundation = house_list[29]
        self.BsmtQual = house_list[30]
        self.BsmtCond = house_list[31]
        self.BsmtExposure = house_list[32]
        self.BsmtFinType1 = house_list[33]
        self.BsmtFinSF1 = house_list[34]
        self.BsmtFinType2 = house_list[35]
        self.BsmtFinSF2 = house_list[36]
        self.BsmtUnfSF = house_list[37]
        self.TotalBsmtSF = house_list[38]
        self.Heating = house_list[39]
        self.HeatingQC = house_list[40]
        self.CentralAir = house_list[41]
        self.Electrical = house_list[42]
        self.FirstFlrSF = house_list[43]
        self.SecondFlrSF = house_list[44]
        self.LowQualFinSF = house_list[45]
        self.GrLivArea = house_list[46]
        self.BsmtFullBath = house_list[47]
        self.BsmtHalfBath = house_list[48]
        self.FullBath = house_list[49]
        self.HalfBath = house_list[50]
        self.BedroomAbvGr = house_list[51]
        self.KitchenAbvGr = house_list[52]
        self.KitchenQual = house_list[53]
        self.TotRmsAbvGrd = house_list[54]
        self.Functional = house_list[55]
        self.Fireplaces = house_list[56]
        self.FireplaceQu = house_list[57]
        self.GarageType = house_list[58]
        self.GarageYrBlt = house_list[59]
        self.GarageFinish = house_list[60]
        self.GarageCars = house_list[61]
        self.GarageArea = house_list[62]
        self.GarageQual = house_list[63]
        self.GarageCond = house_list[64]
        self.PavedDrive = house_list[65]
        self.WoodDeckSF = house_list[66]
        self.OpenPorchSF = house_list[67]
        self.EnclosedPorch = house_list[68]
        self.Three_Season_Porch = house_list[69]
        self.ScreenPorch = house_list[70]
        self.PoolArea = house_list[71]
        self.PoolQC = house_list[72]
        self.Fence = house_list[73]
        self.MiscFeature = house_list[74]
        self.MiscVal = house_list[75]
        self.MoSold = house_list[76]
        self.YrSold = house_list[77]
        self.SaleType = house_list[78]
        self.SaleCondition = house_list[79]
        self.SalePrice = house_list[80]

    #  function to print packaging id
    def house_id_interface(self):
        print("House ID: %i" % self.house_id)

    def ms_sub_class_interface(self):
        if self.MSSubClass == 20:
            print('1-STORY 1946 & NEWER ALL STYLES')
        elif self.MSSubClass == 30:
            print('1-STORY 1945 & OLDER')
        elif self.MSSubClass == 40:
            print('1-STORY W/FINISHED ATTIC ALL AGES')
        elif self.MSSubClass == 45:
            print('1-1/2 STORY - UNFINISHED ALL AGES')
        elif self.MSSubClass == 50:
            print('1-1/2 STORY FINISHED ALL AGES')
        elif self.MSSubClass == 60:
            print('2-STORY 1946 & NEWER')
        elif self.MSSubClass == 70:
            print('2-STORY 1945 & OLDER')
        elif self.MSSubClass == 75:
            print('2-1/2 STORY ALL AGES')
        elif self.MSSubClass == 80:
            print('SPLIT OR MULTI-LEVEL')
        elif self.MSSubClass == 85:
            print('SPLIT FOYER')
        elif self.MSSubClass == 90:
            print('DUPLEX - ALL STYLES AND AGES')
        elif self.MSSubClass == 120:
            print('1-STORY PUD (Planned Unit Development) - 1946 & NEWER')
        elif self.MSSubClass == 150:
            print('1-1/2 STORY PUD - ALL AGES')
        elif self.MSSubClass == 160:
            print('2-STORY PUD - 1946 & NEWER')
        elif self.MSSubClass == 180:
            print('PUD - MULTILEVEL - INCL SPLIT LEV/FOYER')
        elif self.MSSubClass == 190:
            print('2 FAMILY CONVERSION - ALL STYLES AND AGES')