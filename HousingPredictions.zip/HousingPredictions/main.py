from house import House
from csv_read import *

house_table = get_house_data_csv()


for each_house in house_table:
    house = house_table.search(each_house)
    if house.house_id == 1:
        House.house_id_interface()